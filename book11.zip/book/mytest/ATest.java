package mytest;

import org.junit.*;
import static org.junit.Assert.*;

public class ATest {    
  @Test
  public void m1() {
    // Write a test method 
  } 

  @Test
  public void m2() {
    // Write another test method
  }     

  @Before
  public void setUp() throws Exception {
    // Common objects used by test methods may be set up here
  }
}
