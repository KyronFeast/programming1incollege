public class DisplayUnicode {
  public static void main(String[] args) {
    System.out.println("\u6B22\u8FCE \u03b1 \u03b2 \u03b3 " +
      "\u6B22\u8FCE Welcome");
  }
}
